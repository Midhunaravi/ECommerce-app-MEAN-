//creating server
const express = require('express');
const app = express();
//conf env
const dotenv = require('dotenv');
const path = require('path');

const connectDatabase = require('./config/connectDatabase');
const cors = require("cors");
const products = require('./routes/product');
const orders = require('./routes/order');
const exp = require('constants');
app.use(cors());
app.use(express.json())
dotenv.config({ path: path.join(__dirname, 'config', 'config.env') })


    connectDatabase();
    
    app.use('/api/v1/', products);
    app.use('/api/v1/', orders);

    if(process.env.NODE_ENV == 'production'){
      app.use(express.static(path.join(__dirname,'..','frontend','dist','frontend','browser')));
      app.get('*',(req,res) => {
        res.sendFile(path.resolve(__dirname,'..','frontend','dist','frontend','browser','index.html'))
      })
    }
    
    // creating server --set port
    app.listen(process.env.PORT, () => {
      console.log(`Server listening to Port ${process.env.PORT} in ${process.env.NODE_ENV}`);
    });